#include "BaseApplication.h"

class Agent
{
private:
	Ogre::SceneManager* mSceneMgr;
	Ogre::SceneNode* mBodyNode;
	Ogre::Entity* mBodyEntity;
public:
	Agent(Ogre::SceneManager* mSceneManager, std::string name, std::string filename);
	virtual ~Agent();

	void update(Ogre::Real deltaTime);		// update the agent
};