#include "Agent.h"

Agent::Agent(Ogre::SceneManager* mSceneManager, std::string name, std::string filename)
{
	using namespace Ogre;

	mSceneMgr = mSceneManager;
	
	if (mSceneMgr == NULL)
		return;

	mBodyNode = mSceneMgr->getRootSceneNode()->createChildSceneNode();
	mBodyEntity = mSceneMgr->createEntity(name, filename);
	mBodyNode->attachObject(mBodyEntity);

	mBodyNode->translate(0,5,0); // make the Ogre stand on the plane

	Ogre::Entity* mEnt = mSceneMgr->getEntity("Knot1");
	mEnt->detachFromParent();
	mBodyNode->attachObject(mEnt);
	
}

Agent::~Agent()
{
	mSceneMgr->destroySceneNode(mBodyNode); // Note that OGRE does not recommend doing this. It prefers to use clear scene
	mSceneMgr->destroyEntity(mBodyEntity);
} 

void
Agent::update(Ogre::Real deltaTime)
{
	mBodyNode->roll(Ogre::Degree(1.0));
	mBodyNode->pitch(Ogre::Degree(1.0));
}